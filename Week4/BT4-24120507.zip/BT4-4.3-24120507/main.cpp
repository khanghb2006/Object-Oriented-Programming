#include <iostream>
#include "Array.h"

int main() {
    // Array<int> arr;
    // std::cin >> arr; 
    // Array<int> arr2 = arr; 
    // std::cout << arr2 << "\n"; 
    // int *p = (int*) arr2;
    // p[0] = 0;
    // std::cout << arr.operator[](0) << "\n";
    // std::cout << arr2.operator[](0) << "\n";
}