#include <iostream>
#include "Fraction.h"

int main() {
    // Fraction f1(1 , 2);
    // Fraction f2;
    // std::cin >> f2; // 3 4
    // std::cout << (f1 < f2) << "\n";
    // Fraction f3 = f1 + f2;
    // f1 *= f3;
    // f1++;
    // f1--;
    // std::cout << float(f3);
    // std::cout << f1;
}