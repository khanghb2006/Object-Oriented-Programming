#include <iostream>
#include "Monomial.h"

int main() {
    // Monomial m1(3 , 2);
    // Monomial m2;
    // std::cin >> m2; // 4 2
    // m1 += m2;
    // m1 *= m2;
    // m1++;
    // m1--;
    // !m1;
    // std::cout << m1;
}