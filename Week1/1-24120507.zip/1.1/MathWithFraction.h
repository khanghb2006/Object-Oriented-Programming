#pragma once
#include "define.h"

Fraction Inverse (Fraction fraction);

Fraction Add (Fraction frac1 , Fraction frac2);

int CompareTwoFraction (Fraction frac1 , Fraction frac2);