#pragma once
#include "define.h"

void Input (Fraction & fraction);

void Output (Fraction fraction);