#pragma once
#include<iostream>
#include "def.h"

void InputFraction (Fraction *&arr , int &size);
void OutputFraction (Fraction *arr , int size);