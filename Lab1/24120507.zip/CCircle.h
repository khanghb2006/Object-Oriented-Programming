#pragma once
#include "Cpoint.h"

class CCircle {
private:
	CPoint m_center;
	double m_radious;
	bool valid_circle(CPoint center, double radiuos);
public:
	CCircle();
	CCircle(const CCircle& c);
	CCircle(double center_x, double center_y, double radious);
	CPoint get_center() { return m_center; }
	double get_radious() { return m_radious; }
	void set_center(double new_center_x, double new_center_y);	
	void set_radious(double new_radious);
	~CCircle();
};