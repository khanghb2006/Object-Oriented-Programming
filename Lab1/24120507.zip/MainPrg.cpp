#include <iostream>
#include "CCircle.h"
#include "CFraction.h"
#include "CLine.h"
#include "CPoint.h"
#include "CRectangle.h"
#include "CStudent.h"
#include "CTriangle.h"

int main() {
	CPoint *p = new CPoint(5 , 7);
	std::cout << "Point " << p->get_x() << " " << p->get_y() << "\n";
	delete p;

	CLine *l = new CLine(1, 2, 3, 4);
	std::cout << "Line: (" << l->get_start().get_x() << " " << l->get_start().get_y() << ") ("
		<< l->get_end().get_x() << " " << l->get_end().get_y() << ")\n";
	delete l;

	CRectangle *r = new CRectangle(0, 5, 5, 0);
	std::cout << "Rectangle: (" <<  r->get_topLeft().get_x() << " " << r->get_topLeft().get_y() << ") ("
		<< r->get_bottomRight().get_x() << " " << r->get_bottomRight().get_y() << ")\n";
	delete r;

	CTriangle *t = new CTriangle(0, 0, 5, 0, 0, 5);
	std::cout << "Triangle: (" << t->get_A().get_x() << " " << t->get_A().get_y() << ") ("
		<< t->get_B().get_x() << " " << t->get_B().get_y() << ") ("
		<< t->get_C().get_x() << " " << t->get_C().get_y() << ")\n";
	delete t;

	CCircle *c = new CCircle(0, 0, 10);
	std::cout << "Circle: (" << c->get_center().get_x() << " " << c->get_center().get_y() << ") "
		<< c->get_radious() << "\n";
	delete c;

	CFraction *f = new CFraction(3, 4);
	std::cout << "Fraction: " << f->get_num() << " / " << f->get_den() << "\n";
	delete f;

	CStudent* s = new CStudent("Khang", "Bao", "Huynh");
	std::cout << "Student: " << s->get_firstName() << " " << s->get_middleName() << " " << s->get_lastName() << "\n";
	delete s;

	return 0;
}
