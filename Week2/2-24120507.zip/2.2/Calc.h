#pragma once
#include <string>

double solve (std::string s);